ip link add link ens33 macvlan0-host type macvlan mode bridge
ip link set dev macvlan0-host up
ip addr add 192.168.186.254/24 dev macvlan0-host

