mysql -u root -p$MYSQL_ROOT_PASSWORD <<EOSQL
stop slave;
unlock tables;
change  master to master_host='192.168.186.5',master_port=33060,master_user='wang',master_password='wang@123',master_log_file='mysql-bin.000003',master_log_pos=611;
start slave; 
EOSQL
#CHANGE MASTER TO MASTER_HOST='192.168.186.10', MASTER_USER='wang', MASTER_PASSWORD='wang123', MASTER_CONNECT_RETRY=60;

