mysql -u root -p$MYSQL_ROOT_PASSWORD <<EOSQL
grant replication slave,replication client on *.* to wang@'192.168.186.%' identified by 'wang@123';
flush privileges;
flush tables with read lock;
EOSQL
