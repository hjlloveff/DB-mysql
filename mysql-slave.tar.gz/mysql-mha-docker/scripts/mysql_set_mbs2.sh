docker exec -it mha_node2 /bin/bash /root/mha_share/scripts/mysql_start_second.sh
