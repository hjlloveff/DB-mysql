docker stop mha_node2
docker rm mha_node2
rm -fr /root/mysql-mha-docker/volumes/mha_node0/lib
